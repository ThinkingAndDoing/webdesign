<?php
namespace app\common\model;

class Base extends \think\Model {
    
}
