<?php
namespace app\common\controller;

use \think\Controller;

class Base extends Controller {
    
	
}
