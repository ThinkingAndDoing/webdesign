<?php

return [
    'url_route_on' => true,
    /*'log'          => [
        'type' => 'trace',
    ],*/
	'show_error_msg' => true,
	
	//本项目的配置
	"web_name" => "ozgweb",
	"web_root" => "http://192.168.33.10/thinkphp-ozgweb/public/",
	"web_res_root" => "http://192.168.33.10/thinkphp-ozgweb/public/static/",
	"web_page_size" => 16,	
	
];
